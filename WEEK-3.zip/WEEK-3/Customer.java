package com.verizon1;

public class Customer {

	public Integer getBalance() {
		// TODO Auto-generated method stub
		return 5000;
	}

}
