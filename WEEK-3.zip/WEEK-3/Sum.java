package com.verizon;

public class Sum {
	public int addNum(int a,int b) {
		return a+b;
	}

}
