package com.verizon.test;

import org.testng.annotations.Test;

public class SumTest {

  @Test
  public void addNumTest() {
	  System.out.println("anju");
    //throw new RuntimeException("Test not implemented");
  }
}
