
public class SelectorId {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\JAR Files\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
	}
	

}
