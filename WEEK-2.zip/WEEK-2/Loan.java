package com.verizon;

public abstract class Loan {

	
		// TODO Auto-generated method stub
		//abstraction
		abstract  void applyLoan(String name,double amount);
		abstract void submitDocs();
        abstract int getEmi();
	}


