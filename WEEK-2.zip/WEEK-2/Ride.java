package com.verizon.poly;

public class Ride {
	void sq(int s) {
		System.out.println("area of sq:"+(s*s));
		
	}

}
