package com.verizon;

public class AccountDemo {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account account= new Account();
		account.acNumber=101;
		account.name="Ram";
		account.balance=10000.00;
		System.out.println(account);
		System.out.println(account.acNumber +" "+account.name +" "+account.balance+" ");
		

	}

}
