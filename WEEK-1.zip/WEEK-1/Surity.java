package com.tms.interfaces;

public interface Surity {
	void submitDocs2();
	

}
