package com.tms.interfaces;

 interface Parking {
   void getSlot();
   
}
