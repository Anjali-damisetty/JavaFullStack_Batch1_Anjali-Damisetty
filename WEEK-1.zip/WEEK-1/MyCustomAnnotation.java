package com.collections;


public @interface MyCustomAnnotation {
	String value() default "verizon hyderabad";
	int count() default 9999;

}
