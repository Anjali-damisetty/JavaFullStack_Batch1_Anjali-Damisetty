package com.tms.interfaces;

public class vehicleLoan implements Loan,Surity,Parking{
	public void applyLoan(String name,double amount) {

}}
