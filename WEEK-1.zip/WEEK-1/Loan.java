package com.tms.interfaces;

public interface Loan {//abstract,public
	void applyLoan(String name,double amount);
	void submitDocs();
	int getEmi();
	

}
