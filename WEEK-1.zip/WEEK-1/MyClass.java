package com.collections;

public class MyClass {
	@MyCustomAnnotation()
	public void myAnnotationMethod() {
		//Annotated method implementation
	}

}
