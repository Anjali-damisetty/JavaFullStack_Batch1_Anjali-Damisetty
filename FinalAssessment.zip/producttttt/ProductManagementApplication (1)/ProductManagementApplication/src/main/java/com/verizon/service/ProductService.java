package com.verizon.service;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.verizon.dao.ProductDao;
import com.verizon.exception.ProductNotFoundException;
import com.verizon.model.Product;
import jakarta.transaction.Transactional;
@Service
@Transactional
public class ProductService {
	@Autowired
	ProductDao productDao;
	
	public String addProduct(Product product) {
	productDao.save(product);
		return "Added";
	}
	public   List<Product> getProducts() {
		//
		return productDao.findAll();
	}
	
	public   Product getProduct(Integer id) {
		//
		return productDao.findById(id).orElseThrow(()-> new ProductNotFoundException("Product not found: "+id));
		
	}
	
	public   List<Product> getProductsBetweenLowHigh(Integer low,Integer high) {
		// 
		return productDao.findProductsBetweenPrice(low, high);
	}
	public Product updateProduct(Integer pid,Product product) {
		Product existingProduct = productDao.findById(pid).orElseThrow(()-> new ProductNotFoundException("Product not found: "+pid));
		existingProduct.setPname(product.getPname());
		existingProduct.setPrice(product.getPrice());
		return productDao.save(existingProduct);
	}
	public void deleteProduct(Integer pid) {
		Product product = productDao.findById(pid).orElseThrow(()-> new ProductNotFoundException("Product not found: "+pid));
		productDao.delete(product);
		}
	}
