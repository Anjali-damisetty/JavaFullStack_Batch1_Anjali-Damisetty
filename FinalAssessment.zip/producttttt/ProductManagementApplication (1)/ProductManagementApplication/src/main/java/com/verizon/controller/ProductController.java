package com.verizon.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.verizon.model.Product;
import com.verizon.service.ProductService;
@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	
	@GetMapping("/product")
	public List<Product> getAllProducts() {  // need to implement
				return (productService.getProducts());
	}
	
	@GetMapping("/product/{id}")
	public Product getProduct(@PathVariable Integer id) {  // need to implement
			return productService.getProduct(id);
	}
	
	@GetMapping("/product/{low}/{high}")
	public List<Product> getProductBetweenPriceRange(@PathVariable Integer low,@PathVariable Integer high) {  // need to implement
		return productService.getProductsBetweenLowHigh(low, high);
	}
  @PostMapping("/product") 
	  public String  addProductDetails(@RequestBody	  Product product) { // need to implement
	  productService.addProduct(product);
	  return  "Added";
	  }
	
	@PutMapping("/product/{pid}") 
	public Product updateProductDetails(@PathVariable("pid") Integer pid,@RequestBody Product product) {
		return  productService.updateProduct(pid, product);
	}
	
	@DeleteMapping("/product/{pid}") 
	public String deleteProductDetails(@PathVariable("pid") Integer pid) {
		productService.deleteProduct(pid);
		return  "deleted"; 
	}
	
}
